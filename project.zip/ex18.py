print("Menu:\n")
cadas = input("Cadraste-se")