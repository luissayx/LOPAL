atual = 20
hptotal = 100
print("O Hp do seu pokémon é de " + str(atual) + ", deseja melhorar o hp dele?(1:sim, não:2)")
resposta = int(input())
if resposta == 1:
    while atual < hptotal:
        atual = atual + 20
        print("Foi adicionado 20 ao seu hp atual, agora ele é de " + str(atual))
    print("PARABÉNS! seu pokémon foi curado!")
else:
    print("Adeus!")
