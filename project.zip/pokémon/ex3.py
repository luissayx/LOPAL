import random
random.seed()   #Prepare random number generator

sorteio = int(random.random() * 101)
print("Tente capturar o Pokémon")
print("Adicione um número:")
numero = int(input())
if sorteio > 50:
    print("Seu Pokémon foi capturado")
else:
    print("Seu pokémon escapou!")
