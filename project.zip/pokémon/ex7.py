import random
random.seed()   #Prepare random number generator

hp = 120
print("Vamos iniciar o combate?(1=sim, 2=não)")
resposta = int(input())
if resposta == 1:
    while hp > 0:
        print("Deseja atacar?")
        resposta = int(input())
        chance = int(random.random() * 101)
        if resposta == 1:
            if chance >= 50:
                hp = hp - 15
                print("Você acertou o ataque!" + "  Agora o hp do seu oponente é de: " + str(hp))
            else:
                print("Você errou o ataque")
        else:
            print("Você perdeu!")
    print("Você matou!")
else:
    print("Adeus!")
