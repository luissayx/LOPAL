import random
random.seed()   #Prepare random number generator

xp = 0
print("Vamos iniciar o treino?(1=verdadeiro, 2=falso)")
resposta = int(input())
if resposta == 1:
    while xp != 50:
        print("Você vê um boneco, deseja atacar?")
        resposta = int(input())
        repite = int(random.random() * 101)
        if resposta == 1:
            if repite >= 30:
                xp = xp + 10
                print("Você ataca o boneco, seu xp é de " + str(xp))
            else:
                print("Você errou o alvo!")
        else:
            print("Você desistiu!")
    print("Parabéns você ganhou habilidade!")
else:
    print("Adeus!")
