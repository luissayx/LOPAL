import random
random.seed()   #Prepare random number generator

print("Você possui 3 tentativas para jogar a isca!")
print("Você quer jogar a isca?(digite 1: sim ou 2: não)")
resposta = int(input())
if resposta == 1:
    isca = 3
    while isca > 0:
        comer = int(random.random() * 101)
        if comer >= 45:
            print("Um pokemon comeu a isca!")
        else:
            print("Nenhum pokemon comeu a isca...")
        isca = isca - 1
        print("Você tem " + str(isca) + " restante(s)!")
    print("Você não tem iscas!")
else:
    print("Adeus!")
