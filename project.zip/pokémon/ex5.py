print("Se deseja evoluir seu pokémon, digite o nível dele:")
nivel = int(input())
print("Ele está segurando algum item?(Caso não esteja, digitar: 0. Caso esteja: 1)")
item = int(input())
if nivel >= 16 and item == 0:
    print("Seu pokémon foi evoluido!")
else:
    print("Seu pokémon não pode ser evoluido!")
