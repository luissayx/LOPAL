import random
random.seed()   #Prepare random number generator

print("Entramos em uma luta pokemon! O combate é intenso, e você precisa permanecer no controle. Use estratégia para ganhar do seu oponente!")
print("Seus recursos são fornecidos aleatoriamente, então saiba utililza-los com sabedoria!")
spdA = int(random.random() * 100) + 1
spdI = int(random.random() * 100) + 1
hpA = 100
hpI = 120
atq = 15
atq2 = 15
turno = 0
pocao = int(random.random() * 3)
while hpI > 0:
    print("HP do seu pokémon: " + str(hpA))
    print("HP do pokémon oponente: " + str(hpI))
    print("Faça sua escolha: Atacar, Item, Fugir")
    resposta = input()
    if resposta == "Atacar" or resposta == "atacar":
        if spdA > spdI:
            print("Você decidiu atacar seu oponente. Você da um ataque rápido e...")
            chance = int(random.random() * 101)
            if chance >= 50:
                critico = int(random.random() * 101)
                if critico >= 90:
                    atq = atq * 2
                    print("Você fez um acerto crítico!")
                    atq = float(atq) / 2
                else:
                    print("Você acerta seu oponente!")
                hpI = hpI - atq
                if hpI <= 0:
                    print("Você derrotou seu oponente, parabéns!")
            else:
                print("Você errou o ataque!")
            print("Vez do seu oponente atacar, e...")
            chance = int(random.random() * 101)
            if chance >= 50:
                critico = int(random.random() * 101)
                if critico >= 90:
                    atq2 = atq2 * 2
                    print("Seu oponente fez um acerto crítico!")
                    atq2 = float(atq2) / 2
                else:
                    print("Seu oponente te acerta!")
                hpA = hpA - atq2
                if hpA <= 0:
                    print("Você perdeu o duelo!")
            else:
                print("Seu oponente errou o ataque!")
        else:
            print("Seu oponente foi mais rápido, ele começa o turno!")
            print("Vez do seu oponente atacar, e...")
            chance = int(random.random() * 101)
            if chance >= 50:
                critico = int(random.random() * 101)
                if critico >= 90:
                    atq2 = atq2 * 2
                    print("Seu oponente fez um acerto crítico!")
                    atq2 = float(atq2) / 2
                else:
                    print("Seu oponente te acerta!")
                hpA = hpA - atq2
                if hpA <= 0:
                    print("Você perdeu o duelo!")
                    break
            else:
                print("Seu oponente errou o ataque!")
            print("Você decidiu atacar seu oponente. Você da um ataque rápido e...")
            chance = int(random.random() * 101)
            if chance >= 50:
                critico = int(random.random() * 101)
                if critico >= 90:
                    atq = atq * 2
                    print("Você fez um acerto crítico!")
                    atq = float(atq) / 2
                else:
                    print("Você acerta seu oponente!")
                hpI = hpI - atq
                if hpI <= 0:
                    print("Você derrotou seu oponente, parabéns!")
            else:
                print("Você errou o ataque!")
    if resposta == "Item" or resposta == "item":
        if pocao > 0:
            print("Você possui " + str(pocao) + " poção(ões) de cura restante(s). Utilizar?")
            resposta = input()
            if resposta == "Sim" or resposta == "sim":
                pocao = pocao - 1
                print("Você utiliza uma poção.")
                hpA = hpA + 30
                print("Seu pokemon recuperou 30 de Hp!")
                if hpA > 100:
                    hpM = hpA - 100
                    hpA = hpA - hpM
                if pocao > 0:
                    print("Você ainda tem " + str(pocao) + " poção(ões) restante(s).")
            else:
                print("Você não utiliza nenhum item.")
        else:
            print("Você não tem nenhum item restante...")
    if resposta == "Fugir" or resposta == "fugir":
        print("Deseja tentar fugir?")
        resposta = input()
        if resposta == "Sim" or resposta == "sim":
            print("Você tenta fugir e...")
            chance = int(random.random() * 101)
            if chance >= 90:
                print("Você escapou! Essa foi por pouco...")
                break
            else:
                print("Você não consegue fugir!")
