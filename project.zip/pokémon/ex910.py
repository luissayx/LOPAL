import random
random.seed()   #Prepare random number generator

inimigo = 100
critico = 40
dano = 20
vida = 100
print("Vamos para a grande batalha?! Seu inimigo tem 100 de hp e o seu é de 100 também, seu dano para com ele é de 20, assim como o dele para com você é de 20, porém, caso tenha sorte, pode sortear o ataque crítico que dobra! Quer jogar então clique 1 para sim e 2 para não")
resposta = int(input())
if resposta == 1:
    print("Seu adversário tem que ser atacado, clique em 1 para atacar")
    resposta = int(input())
    while resposta == 1:
        chance = int(random.random() * 100)
        if chance >= 40:
            chance = int(random.random() * 100)
            if chance > 70:
                inimigo = inimigo - dano * 2
                print("Você deu um acerto crítico!")
            else:
                inimigo = inimigo - dano
            if inimigo > 0:
                pass
            else:
                print("Você matou seu oponente!")
                break
            print("A vida do seu oponente é de " + str(inimigo))
        else:
            print("Você errou o ataque!")
        print("Hora do seu oponente atacar!")
        chance = int(random.random() * 100)
        if chance >= 50:
            vida = vida - dano
            print("Seu adversário te atacou! Sua vida é de " + str(vida))
            if vida <= 0:
                print("Você morreu!")
                break
        else:
            print("Ele errou o ataque! Sua vida é de " + str(vida))
        print("Clique 1 para atacar novamente!")
        resposta = int(input())
else:
    print("Adeus!")
