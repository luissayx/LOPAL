print("Escolha um ataque-fogo;agua;folha")
tipoataque = input()
print("Escolha o tipo de defensa-agua,fogo,folha:")
tipodefesa = input()
if tipoataque == "agua" and tipodefesa == "fogo" or tipoataque == "fogo" and tipodefesa == "folha" or tipoataque == "folha" and tipodefesa == "agua":
    print("Super efetivo!")
else:
    if tipoataque == "fogo" and tipodefesa == "agua" or tipoataque == "folha" and tipodefesa == "fogo" or tipoataque == "agua" and tipodefesa == "folha":
        print("Dano pouco efetivo!")
    else:
        print("Dano normal!")
