print("Digite o seu poder base:")
poderbase = float(input())
bonus = poderbase * 2
print("Você recebeu um bônus de 2, seu dano final é " + str(bonus))
