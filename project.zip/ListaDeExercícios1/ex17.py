print("Lista de tickets: \n")
lista = ["ticket 1", "tickets 2", "ticket 3", "ticket 4"]
for tick in lista:
    print(tick)
lista.remove(input("Qual ticket você deseja remover:\n"))
print()
print("Lista de tickets:")
for tick in lista:
    print(tick)
